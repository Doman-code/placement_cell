import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header2',
  templateUrl: './header2.component.html',
  styleUrls: ['./header2.component.scss']
})
export class Header2Component  implements OnInit {
  images: string[] = ['https://images.pexels.com/photos/5211478/pexels-photo-5211478.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', 'https://images.unsplash.com/photo-1562774053-701939374585?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=886&q=80', '../../../../../assets/images/photo-1523050854058-8df90110c9f1.avif']; // List of image sources
  texts: string[] = ['DOMAN 4LPA', 'DAULAT 5LPA', 'SAURABH 13LPA'];
  currentIndex = 0; // Current index of the image being displayed
  currentImage!: string; // Current image source
  currentText!: string; // Current text

  imageHeight = '33vh'; // Set the desired height for the images
  imageWidth = '66vh'; 
  constructor() { }

  ngOnInit() {
    this.startAutoplay();
  }

  startAutoplay() {
    setInterval(() => {
      this.autoplayImage();
    }, 3000);
  }

  autoplayImage() {
    this.currentImage = this.images[this.currentIndex]; // Set the current image source
    this.currentText = this.texts[this.currentIndex];

    // Increment the current index and wrap around to the beginning if necessary
    this.currentIndex = (this.currentIndex + 1) % this.images.length;
  }
}